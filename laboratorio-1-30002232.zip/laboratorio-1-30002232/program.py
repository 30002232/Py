from base64 import encode
import sys
import view

sys.stdout.reconfigure(encoding='utf-8')

if __name__ == "__main__":
    view.main()