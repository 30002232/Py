import controller

def main(): 
    
    matrizConsultores = []
    matrizImoveis = []
    id = "0"

    while True:
        try:
            user_input = input("").split(" ")
            registo = user_input[1:]
            op = user_input[0].upper()

            if (op == "RC"):
                if (controller.verificarEleMatriz(2, registo[2], matrizConsultores)):
                    print("Não ́é possível realizar o registo, consultor já registado.")
                else:
                    controller.inserirMatriz(registo, matrizConsultores)
                    print("Consultor registado com sucesso.")
                
            elif (op == "RI"):
                if (len(registo) != 7):
                    print("Por favor verifique se todas as informações foram introduzidas.")
                elif(controller.verificarEleMatriz(2, registo[0], matrizConsultores) == False):
                    print("Não é possivel realizar o registo do imóvel, NIF inválido.")
                else:
                    id = controller.inserirMatrizAddId(id, registo, matrizImoveis)
                    print("Imóvel com " + id + " registado com sucesso.")

            elif (op == "LI"):
                if (controller.verificarEleMatriz(2, registo[0], matrizConsultores) == False):
                    print("Não é possível realizar a operação, NIF inválido")
                elif (controller.verificarEleMatriz(1, registo[0], matrizImoveis) == False):
                    print("Não existem imóveis registados.")
                else:
                    controller.printMatriz(1, registo[0], matrizImoveis)

            elif (op == "EI"):
                if (controller.verificarEleMatriz(0, registo[1], matrizImoveis) == False):
                    print("O ID indicado é inválido")
                elif(controller.eliminarImovel(registo, matrizImoveis) == False):
                    print("O imóvel " + registo[1] + " não pertence ao consultor indicado.") 
                else:
                    print("Imóvel eliminado com sucesso.")

            elif (op == "EC"):
                if (controller.verificarEleMatriz(2, registo[0], matrizConsultores) == False):
                    print("Não é possivel realizar a operação, NIF inválido.")
                else:
                    imoveisEliminados = controller.eliminarVariosImoveis(registo[0], matrizImoveis)
                        
                    if (imoveisEliminados != []):
                        controller.eliminarConsultor(registo, matrizConsultores)
                        print("Consultor eliminado com sucesso.")
                        msg = controller.imprimirEliminados(imoveisEliminados)
                        print("Os imóveis " + msg + " também foram eliminados")
        except EOFError:
            return

