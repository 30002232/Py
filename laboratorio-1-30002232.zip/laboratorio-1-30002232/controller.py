#Verifica um elemento numa matriz
#Recebe como parametros a posição do elemento na matriz, o valor a comparar e a matriz
#Retorna verdadeiro ou falso  
def verificarEleMatriz(posEleMatriz, valElemento, matriz): 
    if (matriz != []):
        for i in range (len(matriz)):
            if (valElemento == matriz[i][posEleMatriz]):
                return True
    return False

#Insere um elemento na matriz
#Recebe como parametros uma lista com os valores e a matriz
#Retorno vazio
def inserirMatriz(reg, matriz):
    matriz.append(reg)

#Insere o ID na matriz
#Recebe como parametros uma lista com os valores a matriz e o ultimo id
#Retorna o id gerado
def inserirMatrizAddId(id, reg, matriz):
    id = int(id) + 1
    id = str(id)
    reg.insert(0, id)
    matriz.append(reg)
    return id

#Imprime no ecrã valores filtrados.
#Recebe como parametros a posição do elemento a filtrar na matriz, o valor e a matriz
#Retorno vazio
def printMatriz(posFiltro, strFiltro,  matriz):
    for i in range(len(matriz)):
        msg = ""
        for j in range(len(matriz[i])):
            if (matriz[i][posFiltro] == strFiltro):
                msg = matriz[i][0] + " " + matriz[i][-2] + " " + matriz[i][-1]
        if (msg != ""):
            print (msg)

#Especificando dois valores elimina um elemento na matriz
##Recebe como parametros uma lista com dois valores e a matriz
#Retorna verdadeiro ou falso 
def eliminarImovel(reg, matriz):
    for i in range(len(matriz)):
        if (reg[0] == matriz[i][1] and reg[1] == matriz[i][0]):
            matriz.remove(matriz[i])
            return True
    return False

#Especificando um valor elimina um elemento na matriz
##Recebe como parametros uma lista com um valor e a matriz
#Retorna verdadeiro ou falso 
def eliminarConsultor(reg, matriz):
    for i in range(len(matriz)):
        if (reg[0] == matriz[i][2]):
            matriz.remove(matriz[i])
            return True
    return False

#Elimina varios elemento na matriz
##Recebe como parametros um valor e a matriz
#Retorna uma lista com os elementos eliminados
def eliminarVariosImoveis(reg, matriz):
    imoveisEliminados = []
    i = 0
    while i < len(matriz):
        if (reg == matriz[i][1]):
            imoveisEliminados.append(matriz[i][0])
            matriz.remove(matriz[i])
            continue
        i = i + 1
    return imoveisEliminados

#Imprime os id´s dos imoveis eliminados
#Recebe como parametro a lista com os numeros
#Retorna uma string com o(s) id  
def imprimirEliminados(matriz):
    strEliminados = ""
    n = 0
    tamMatriz = len(matriz) - 1
    while n <= tamMatriz:
        if (n != tamMatriz):
            strEliminados = strEliminados + (matriz[n] + " ")
        else:
            strEliminados = strEliminados + (matriz[n])
        n = n + 1
    return strEliminados

    
